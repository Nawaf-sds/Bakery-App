const mongoose = require('mongoose');
const Product = require('./Product');

mongoose.connect('mongodb://127.0.0.1:27017/bakeryDB')
  .then(async () => {
    const products = [
      {
        name: "كوكيز الشوكولاتة",
        description: "كوكيز لذيذ مع قطع الشوكولاتة",
        price: 18,
        image: "https://example.com/cookies.jpg",
        ingredients: ["دقيق", "سكر", "زبدة", "شوكولاتة"],
        size: "كبير",
        category: "كوكيز"
      },
      {
        name:  "كيكة الفانيليا",
        description: "وكيكة فانيليا ناعمة ولذيذة",
        price: 20,
        image: "https://example.com/cake.jpg",
        ingredients: ["دقيق", "سكر", "زبدة", "فانيليا"],
        size: "صغير",
        category: "كيك"
      }
        ,
        {
            name: "خبز القمح الكامل",
            description: "خبز صحي مصنوع من دقيق القمح الكامل",
            price: 15,
            image: "https://example.com/bread.jpg",
            ingredients: ["دقيق قمح كامل", "ماء", "خميرة"],
            size: "متوسط",
            category: "خبز"
        },
        {
            name: "مافن التوت",
            description: "مافن لذيذ مع قطع التوت الطازج",
            price: 12,
            image: "https://example.com/muffin.jpg",
            ingredients: ["دقيق", "سكر", "زبدة", "توت"],
            size: "صغير",
            category: "مافن"
        },
        {
            name: "كرواسون الزبدة",
            description: "كرواسون فرنسي تقليدي مع زبدة غنية",
            price: 10,
            image: "https://example.com/croissant.jpg",
            ingredients: ["دقيق", "زبدة", "خميرة"],
            size: "متوسط",
            category: "كرواسون"
        },
        {
            name: "بسكويت الشوفان",
            description: "بسكويت صحي مصنوع من الشوفان والعسل",
            price: 8,
            image: "https://example.com/oatmeal-cookie.jpg",
            ingredients: ["شوفان", "عسل", "زبدة"],
            size: "صغير",
            category: "بسكويت"
        },

      // أضف المزيد هنا
    ];

    const insertedProducts = await Product.insertMany(products);
    console.log("تمت إضافة جميع المنتجات بنجاح");
    console.log("تفاصيل المنتجات المضافة:");
    insertedProducts.forEach(product => {
      console.log(product);
    });
    mongoose.disconnect();
  })
  .catch(err => console.error(err));

  