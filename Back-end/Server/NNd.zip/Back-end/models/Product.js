const mongoose = require('mongoose');
const { applyVirtuals } = require('./user');

const productSchema = new mongoose.Schema({

    name: {
        type: String,
        required: true,
        trim: true,  
    },
    description : {
        type: String,
        required: true,
    },

    price:{
        type: Number,
        required: true,

    },
    image:{
        type: String, 
        required: true,
    },
    ingredients: {
        type: [String],
        required: true,
    },
    size:{
        type: String,
        enum: ['كبير','متوسط','صغير'],
        required: true,
    },
    category: {
        type: String,
        // enum: ['بيتزا', 'برجر', 'مشروبات', 'حلويات'],
        required: true,
    },
    applyVirtuals: {
        type: Boolean, 
        default: true,
    },
    
    createdAt: {
        type: Date,
        default: Date.now,
    },
    updatedAt: {
        type: Date,
        default: Date.now,
    }

});

  

     module.exports = mongoose.model('Product', productSchema);
     // This is a placeholder schema for the Product model.