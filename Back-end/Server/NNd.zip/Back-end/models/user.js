const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({

    name:{
        type: String,
        required: true,
        trim: true
    },

   email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true, // تصحيح lowrcase إلى lowercase
   },
    password: {
          type: String,
          required: true,
          minlength: 6,
          select: false // لا يتم إرجاع كلمة المرور في الاستعلامات
          
     },

     role: {
          type: String,
          enum: ['customer', 'admin' , 'employee'],
          default: 'customer'
     },
    
     createdAt: {
          type: Date,
          default: Date.now
     },
    
     updatedAt: {
          type: Date,
          default: Date.now
     }

});

module.exports = mongoose.models.User || mongoose.model('User', userSchema);
// This is a placeholder schema for the User model.