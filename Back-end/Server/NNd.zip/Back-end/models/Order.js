const mongoose = require('mongoose');

const orderItemSchema = new mongoose.Schema({
  product: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: true
  },
  quantity: {
    type: Number,
    required: true,
    min: 1
  }
});

const orderSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  items: [orderItemSchema],
  totalPrice: {
    type: Number,
    required: true
  },
  paymentMethod: {
    type: String,
    enum: ['عند الاستلام', 'مدى', 'Apple Pay', 'بطاقة ائتمان'],
    required: true
  },
  status: {
    type: String,
    enum: ['قيد التجهيز', 'قيد التوصيل', 'مكتمل', 'ملغي'],
    default: 'قيد التجهيز'
  },
  deliveryTime: {
    type: Date
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Order', orderSchema);
// This is a placeholder schema for the Order model.
// It includes user reference, items, total price, payment method, status, delivery time,