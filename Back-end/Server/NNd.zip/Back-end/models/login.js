const express = require('express');
const router = express.Router();
// const jwt = require('jsonwebtoken'); // يمكنك استخدام JWT لإنشاء توكنات للمستخدم 
// const bcrypt = require('bcryptjs'); // يمكنك استخدام bcrypt لتشفير كلمات المرور

// تسجيل دخول المستخدم
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user || user.password !== password) {
      return res.status(401).json({ message: 'بيانات الدخول غير صحيحة' });
    }
    // لا ترسل كلمة المرور مع البيانات
    const { password: _, ...userData } = user.toObject();
    res.json({ message: 'تم تسجيل الدخول بنجاح', user: userData });
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ في السيرفر' });
  }
});

module.exports = router;