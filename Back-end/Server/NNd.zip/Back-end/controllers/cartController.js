const Cart = require('../models/Cart');

const addToCart = async (req, res) => {
  try {
    const cart = new Cart(req.body);
    const saved = await cart.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

const getCart = async (req, res) => {
  try {
    const cart = await Cart.find();
    res.json(cart);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = {
  addToCart,
  getCart
};
