const Order = require('../models/Order');

// إنشاء طلب جديد
const createOrder = async (req , res) => {
    try  {
        const newOrder = new Order(req.body);
        const savedOrder = await newOrder.save();
        res.status(201).json(savedOrder); // تصحيح اسم المتغير
    } catch (err){
        res.status(500).json({ message: 'خطأ في إنشاء الطلب', error: err.message });
    }
};


// الحصول على جميع الطلبات
const getAllOrders = async (req, res) => {
    try {
        const orders = await Order.find();
        res.status(200).json(orders);
    } catch (err) {
        res.status(500).json({ message: 'خطأ في جلب الطلبات', error: err.message });
    }
};

// جلب طلبات المستخدم الحالي
const getMyOrders = async (req, res) => {
    try {
        const orders = await Order.find({ user: req.user._id });
        res.status(200).json(orders);
    } catch (err) {
        res.status(500).json({ message: 'خطأ في جلب طلبات المستخدم', error: err.message });
    }
};

module.exports = {
    createOrder,    
    getAllOrders,
    getMyOrders
};






