// const express = require('express');
// const router = express.Router();
// const Delivery = require('../models/Delivery');

// // ✅ إنشاء بيانات توصيل
// router.post('/', async (req, res) => {
//   const { order, address, city, deliveryNote, company } = req.body;

//   const delivery = new Delivery({
//     order,
//     address,
//     city,
//     deliveryNote,
//     company
//   });

//   try {
//     const saved = await delivery.save();
//     res.status(201).json(saved);
//   } catch (err) {
//     res.status(400).json({ message: err.message });
//   }
// });

// // ✅ جلب بيانات التوصيل لطلب
// router.get('/:orderId', async (req, res) => {
//   try {
//     const delivery = await Delivery.findOne({ order: req.params.orderId });
//     res.json(delivery);
//   } catch (err) {
//     res.status(404).json({ message: 'لم يتم العثور على التوصيل' });
//   }
// });

// // ✅ تحديث حالة التوصيل
// router.put('/:orderId', async (req, res) => {
//   try {
//     const updated = await Delivery.findOneAndUpdate(
//       { order: req.params.orderId },
//       { deliveryStatus: req.body.deliveryStatus },
//       { new: true }
//     );
//     res.json(updated);
//   } catch (err) {
//     res.status(400).json({ message: err.message });
//   }
// });

// // ✅ حذف بيانات التوصيل
// router.delete('/:orderId', async (req, res) => {
//   try {
//     await Delivery.findOneAndDelete({ order: req.params.orderId });
//     res.json({ message: 'تم حذف بيانات التوصيل' });
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// });

// module.exports = router;


const express = require('express');
const router = express.Router();
const {
  createDelivery,
  getDeliveries
} = require('../controllers/deliveryController');

router.post('/', createDelivery);
router.get('/', getDeliveries);

module.exports = router;
