const express = require('express');
const router = express.Router();
const User = require('../models/User');

//تسجيل الدخول والتسجيل
const { registerUser, loginUser } = require('../controllers/authController');
router.post('/register', registerUser);
router.post('/login', loginUser);

// ✅ إنشاء مستخدم جديد (تسجيل)
router.post('/', async (req, res) => {
  const { name, email, password, phone, address, role } = req.body;

  const user = new User({
    name,
    email,
    password,
    phone,
    address,
    role
  });

  try {
    const newUser = await user.save();
    res.status(201).json(newUser);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// ✅ جلب جميع المستخدمين
router.get('/', async (req, res) => {
  try {
    const users = await User.find().select('-password'); // لا نعرض كلمات المرور
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// module.exports = router;
// ✅ جلب مستخدم حسب ID
router.get('/:id', async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password'); // لا نعرض كلمة المرور
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ✅ تحديث مستخدم حسب ID
router.put('/:id', async (req, res) => {
    const { name, email, phone, address, role } = req.body;
    
    try {
        const user = await User.findByIdAndUpdate(
        req.params.id,
        { name, email, phone, address, role },
        { new: true }
        ).select('-password'); // لا نعرض كلمة المرور
    
        if (!user) {
        return res.status(404).json({ message: 'User not found' });
        }
    
        res.json(user);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
    });
// ✅ حذف مستخدم حسب ID
router.delete('/:id', async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json({ message: 'User deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}); 
module.exports = router;











