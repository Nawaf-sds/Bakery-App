
const express = require('express');
const router = express.Router();
const loginController = require('../models/login');

// ربط مسار تسجيل الدخول
router.use('/', loginController);

module.exports = router;
