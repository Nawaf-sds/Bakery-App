// const express = require('express');
// const router = express.Router();
// const Coupon = require('../models/Coupon');

// // ✅ إضافة كوبون جديد
// router.post('/', async (req, res) => {
//   const { code, discount, expiresAt, active } = req.body;

//   const coupon = new Coupon({
//     code,
//     discount,
//     expiresAt,
//     active
//   });

//   try {
//     const saved = await coupon.save();
//     res.status(201).json(saved);
//   } catch (err) {
//     res.status(400).json({ message: err.message });
//   }
// });

// // ✅ جلب جميع الكوبونات
// router.get('/', async (req, res) => {
//   try {
//     const coupons = await Coupon.find();
//     res.json(coupons);
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// });

// // ✅ تعديل كوبون
// router.put('/:id', async (req, res) => {
//   try {
//     const updated = await Coupon.findByIdAndUpdate(req.params.id, req.body, { new: true });
//     res.json(updated);
//   } catch (err) {
//     res.status(400).json({ message: err.message });
//   }
// });

// // ✅ حذف كوبون
// router.delete('/:id', async (req, res) => {
//   try {
//     await Coupon.findByIdAndDelete(req.params.id);
//     res.json({ message: 'تم حذف الكوبون بنجاح' });
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// });

// module.exports = router;


const express = require('express');
const router = express.Router();
const {
  createCoupon,
  getCoupons
} = require('../controllers/couponController');

router.post('/', createCoupon);
router.get('/', getCoupons);

module.exports = router;
