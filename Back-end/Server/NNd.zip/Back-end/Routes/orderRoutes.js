// const express = require('express');
// const router = express.Router();
// const Order = require('../models/Order');

// // ✅ إنشاء طلب جديد
// router.post('/', async (req, res) => {
//   const { user, items, totalPrice, paymentMethod, deliveryTime } = req.body;

//   const order = new Order({
//     user,
//     items,
//     totalPrice,
//     paymentMethod,
//     deliveryTime
//   });

//   try {
//     const newOrder = await order.save();
//     res.status(201).json(newOrder);
//   } catch (err) {
//     res.status(400).json({ message: err.message });
//   }
// });

// // ✅ جلب كل الطلبات
// router.get('/', async (req, res) => {
//   try {
//     const orders = await Order.find()
//       .populate('user', 'name email')
//       .populate('items.product', 'name price');
//     res.json(orders);
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// });

// // ✅ تحديث حالة الطلب (status)
// router.put('/:id', async (req, res) => {
//   try {
//     const updatedOrder = await Order.findByIdAndUpdate(
//       req.params.id,
//       { status: req.body.status },
//       { new: true }
//     );
//     res.json(updatedOrder);
//   } catch (err) {
//     res.status(400).json({ message: err.message });
//   }
// });

// // ✅ حذف طلب
// router.delete('/:id', async (req, res) => {
//   try {
//     await Order.findByIdAndDelete(req.params.id);
//     res.json({ message: 'تم حذف الطلب بنجاح' });
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// });

// module.exports = router;

const express = require('express');
const router = express.Router();

const {
  createOrder,
  getAllOrders,
  getMyOrders // إضافة getMyOrders هنا
} = require('../controllers/orderController');

const { protect } = require('../middleware/authMiddleware');
// ✅ يتطلب توثيق -انشاء طلب
router.post('/', protect, createOrder);

// ✅ جلب طلبات المستخدم المسجل فقط
router.get('/myorders', protect, getMyOrders);

module.exports = router;
