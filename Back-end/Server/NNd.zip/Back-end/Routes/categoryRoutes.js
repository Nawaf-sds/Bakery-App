// const express = require('express');
// const router = express.Router();
// const Category = require('../models/Category');

// // ✅ إضافة تصنيف جديد
// router.post('/', async (req, res) => {
//   const { name, description, image, isActive } = req.body;

//   const category = new Category({
//     name,
//     description,
//     image,
//     isActive
//   });

//   try {
//     const saved = await category.save();
//     res.status(201).json(saved);
//   } catch (err) {
//     res.status(400).json({ message: err.message });
//   }
// });

// // ✅ عرض التصنيفات
// router.get('/', async (req, res) => {
//   try {
//     const categories = await Category.find();
//     res.json(categories);
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// });

// // ✅ تعديل تصنيف
// router.put('/:id', async (req, res) => {
//   try {
//     const updated = await Category.findByIdAndUpdate(req.params.id, req.body, { new: true });
//     res.json(updated);
//   } catch (err) {
//     res.status(400).json({ message: err.message });
//   }
// });

// // ✅ حذف تصنيف
// router.delete('/:id', async (req, res) => {
//   try {
//     await Category.findByIdAndDelete(req.params.id);
//     res.json({ message: 'تم حذف التصنيف بنجاح' });
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// });

// module.exports = router;


const express = require('express');
const router = express.Router();
const {
  createCategory,
  getCategories
} = require('../controllers/categoryController');

router.post('/', createCategory);
router.get('/', getCategories);

module.exports = router;
