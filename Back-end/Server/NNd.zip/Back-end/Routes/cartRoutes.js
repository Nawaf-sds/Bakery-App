const express = require('express');
const router = express.Router();
const {
  addToCart,
  getCart
} = require('../controllers/cartController');
// const { protect } = require('../middleware/authMiddleware'); // تم تعطيل الحماية مؤقتاً للاختبار

router.post('/', addToCart);
router.get('/', getCart);

// ✅ عرض سلة مستخدم معين
router.get('/:userId', async (req, res) => {
  try {
    const cart = await Cart.findOne({ user: req.params.userId }).populate('items.product');
    res.json(cart || { message: 'لا توجد سلة لهذا المستخدم' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ✅ إضافة أو تعديل عنصر في السلة
// router.post('/add', protect, addToCart, async (req, res) => { // تم تعطيل الحماية مؤقتاً
router.post('/add', addToCart, async (req, res) => {
  const { user, items, totalPrice } = req.body;
  try {
    const existingCart = await Cart.findOne({ user });
    if (existingCart) {
      existingCart.items = items;
      existingCart.totalPrice = totalPrice;
      existingCart.updatedAt = Date.now();
      const updated = await existingCart.save();
      res.json(updated);
    } else {
      const newCart = new Cart({ user, items, totalPrice });
      const saved = await newCart.save();
      res.status(201).json(saved);
    }
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// ✅ حذف عنصر من السلة
// router.delete('/:userId/:itemId', protect, async (req, res) => { // تم تعطيل الحماية مؤقتاً
router.delete('/:userId/:itemId', async (req, res) => {
  try {
    const cart = await Cart.findOne({ user: req.params.userId });
    if (!cart) return res.status(404).json({ message: 'السلة غير موجودة' });
    cart.items = cart.items.filter(item => item._id.toString() !== req.params.itemId);
    await cart.save();
    res.json(cart);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ✅ حذف السلة بالكامل
// router.delete('/:userId', protect, async (req, res) => { // تم تعطيل الحماية مؤقتاً
router.delete('/:userId', async (req, res) => {
  try {
    await Cart.findOneAndDelete({ user: req.params.userId });
    res.json({ message: 'تم حذف السلة' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
