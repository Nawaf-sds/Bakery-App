const express = require('express');
const router = express.Router();



// ✅ استدعاء دوال التحكم من controller
const {
  createProduct,
  getAllProducts,
  updateProduct,
  deleteProduct
} = require('../controllers/productController');

// ➕ إنشاء منتج
router.post('/', createProduct);

// 📃 عرض كل المنتجات
router.get('/', getAllProducts);

// 📝 تحديث منتج باستخدام ID
router.put('/:id', updateProduct);

// ❌ حذف منتج باستخدام ID
router.delete('/:id', deleteProduct);

module.exports = router;
