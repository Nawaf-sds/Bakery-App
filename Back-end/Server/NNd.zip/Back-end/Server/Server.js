// const express = require('express');
// // استخدم dotenv مرة واحدة فقط مع المسار الصحيح
// require('dotenv').config({ path: 'Back-end/PORT.env' });

// const app = express();
// const connectDB = require('../MongoDB/MongoDB');

// // ✅ تشغيل MongoDB
// connectDB();

// // ✅ تمكين JSON
// app.use(express.json());

// // ✅ استيراد كل المسارات
// const userRoutes = require('../Routes/userRoutes');
// const orderRoutes = require('../Routes/orderRoutes');
// const cartRoutes = require('../Routes/cartRoutes');
// const deliveryRoutes = require('../Routes/deliveryRoutes');
// const couponRoutes = require('../Routes/couponRoutes');
// const categoryRoutes = require('../Routes/categoryRoutes');
// const productRoutes = require('../Routes/productRoutes');

// // ✅ ربط المسارات
// app.use('/api/products', productRoutes);
// app.use('/api/users', userRoutes);
// app.use('/api/orders', orderRoutes);
// app.use('/api/cart', cartRoutes);
// app.use('/api/delivery', deliveryRoutes);
// app.use('/api/coupons', couponRoutes);
// app.use('/api/categories', categoryRoutes);

// // ✅ تشغيل السيرفر
// const PORT = process.env.PORT || 5000;
// app.listen(PORT, () => {
//   console.log(`🚀 Server running at: http://localhost:${PORT}`);
// });

// node Back-end/Server/Server.js

const express = require('express');
const app = express(); // ✅ استخدم app فقط
app.use(express.json());

const connectDB = require('../MongoDB/MongoDB');

// استيراد المسارات
const userRoutes = require('../Routes/userRoutes');
const orderRoutes = require('../Routes/orderRoutes');
const cartRoutes = require('../Routes/cartRoutes');
const deliveryRoutes = require('../Routes/deliveryRoutes');
const couponRoutes = require('../Routes/couponRoutes');
const categoryRoutes = require('../Routes/categoryRoutes');
const productRoutes = require('../Routes/productRoutes');
const loginRoutes = require('../Routes/loginRoutes'); // تأكد من تعديل المسار حسب هيكل مشروعك
// استخدام dotenv لتحميل المتغيرات البيئية
// استخدام المسارات
app.use('/api/users', userRoutes);
app.use('/api/users', loginRoutes); // تأكد أن loginRoutes في النهاية بعد userRoutes
app.use('/api/orders', orderRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/delivery', deliveryRoutes);
app.use('/api/coupons', couponRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/products', productRoutes);

// الاتصال بقاعدة البيانات
connectDB();

// تشغيل السيرفر
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
